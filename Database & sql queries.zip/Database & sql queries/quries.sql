SELECT Blood_Group, COUNT(*) AS NumberOfDonors FROM DONOR GROUP BY Blood_Group HAVING COUNT(*) > 1 ORDER BY NumberOfDonors DESC;
SELECT D.Name, D.Contact, D.Blood_Group, COUNT(BB.Bag_ID) AS NumberOfDonations FROM DONOR D JOIN blood_bags BB ON D.D_CNIC = BB.D_CNIC WHERE D.Blood_Group = 'A+' GROUP BY  D.Name, D.Contact, D.Blood_Group ORDER BYmNumberOfDonations DESC;
SELECT Bag_ID, Donation_Date, Delivery_Date FROM BLOOD_BAGS WHERE Delivery_Date = '2024-06-05';
SELECT d.Name AS 'Donor Name', COUNT(bb.Bag_ID) AS Blood_Bag_Count FROM DONOR d  JOIN BLOOD_BAGS bb ON d.D_CNIC = bb.D_CNIC
GROUP BY d.Name;
SELECT s.S_ID AS 'Staff_ID', s.Name, COUNT(bb.Bag_ID) AS Blood_Bag_Manage FROM STAFF s JOIN BLOOD_BAGS bb ON s.S_ID = bb.S_ID  GROUP BY s.S_ID, s.Name;
SELECT COUNT(bb.Bag_ID) AS Total_Bags, n.N_ID AS Network_ID, n. Institute_Name, bb.Donation_Date FROM BLOOD_BAGS bb JOIN NETWORKS n ON bb.Bag_ID = n.N_ID  WHERE n.N_ID = 3;
SELECT  bb.Bag_ID,  bb.Donation_Date,  DATE_ADD(bb.Donation_Date, INTERVAL 42 DAY) AS Expiry_Date FROM  BLOOD_BAGS bb  ORDER BY  Expiry_Date;
SELECT  d.D_CNIC AS Donor_identity, d.Name AS Donor_Name, Contact,  d.Blood_Group, 'Eligible' AS Eligibility_Status  FROM  DONOR d  WHERE NOT EXISTS (SELECT 1 FROM  BLOOD_BAGS bb  WHERE  bb.D_CNIC = d.D_CNIC ) OR ( SELECT MAX(bb.Donation_Date)   FROM BLOOD_BAGS bb WHERE  bb.D_CNIC = d.D_CNIC) <= DATE_SUB(CURRENT_DATE, INTERVAL 90 DAY);
SELECT DATE_FORMAT(bb.Donation_Date, '%Y-%m') AS Month, COUNT(bb.Bag_ID) AS Blood_Bag_Count  FROM BLOOD_BAGS bb GROUP BY DATE_FORMAT(bb.Donation_Date, '%Y-%m');
SELECT BB.Bag_ID, BB.Delivery_Date,  ADDDATE(BB.Delivery_Date, 30) AS Expiry_date, D.Name AS Donor_Name, D.Blood_Group, COUNT(BB.Bag_ID) AS NumberOfBags FROM blood_bags BB JOIN DONOR D ON BB.D_CNIC = D.D_CNIC GROUP BY BB.Bag_ID, BB.Delivery_Date, D.Name, D.Blood_Group ORDER BY Expiry_date;
SELECT S.S_ID, S.NAME, S.CONTACT FROM STAFF S WHERE S.S_ID IN(SELECT B.S_ID FROM BLOOD_BAGS B WHERE B.N_ID IS NOT NULL );
SELECT D.D_CNIC, D.BLOOD_GROUP, R.R_CNIC,R.NAME, R.INSTITUTE FROM DONOR D, RECIPIENT R WHERE (D.D_CNIC, R.R_CNIC) IN (SELECT D_CNIC, R_CNIC FROM BLOOD_BAGS WHERE DELIVERY_DATE IS NOT NULL);
SELECT * FROM RECIPIENT WHERE R_CNIC IN (SELECT R_CNIC FROM BLOOD_BAGS WHERE D_CNIC IN (SELECT D_CNIC FROM DONOR WHERE BLOOD_GROUP='A+'));
SELECT N.N_ID, N.INSTITUTE_NAME, N.CONTACT, B.BAG_ID FROM NETWORKS N INNER JOIN BLOOD_BAGS B ON N.N_ID=B.N_ID;
CALL GetEligibleDonors();
CALL GetBloodBagCountsByMonth();
CALL GetBloodBagDetails();
CREATE FUNCTION CalculateExpiryDate(delivery_date DATE)
RETURNS DATE
BEGIN
    DECLARE expiry_date DATE;
    SET expiry_date = ADDDATE(delivery_date, 30);
    RETURN expiry_date;
END;
