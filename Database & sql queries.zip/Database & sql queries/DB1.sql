create database Namal_Blood_Bank;
use Namal_blood_bank;
CREATE TABLE staff (  S_ID INT NOT NULL AUTO_INCREMENT,    NAME CHAR(50) NOT NULL,    CONTACT CHAR(12) NOT NULL,    CNIC CHAR(15) NOT NULL,    ADDRESS VARCHAR(50),    PRIMARY KEY (S_ID));
CREATE TABLE DONOR (D_CNIC CHAR(15) NOT NULL PRIMARY KEY,    Name CHAR(50) NOT NULL,    Contact CHAR(12) NOT NULL,    Department CHAR(15),    Category CHAR(15),
Blood_Group CHAR(3) NOT NULL);
CREATE TABLE Recipient ( R_CNIC CHAR(15) NOT NULL PRIMARY KEY,    NAME CHAR(50) NOT NULL,    CONTACT CHAR(12) NOT NULL,    ADDRESS VARCHAR(100),
    INSTITUTE VARCHAR(100));

CREATE TABLE NETWORKS (N_ID INT NOT NULL AUTO_INCREMENT,    Institute_Name VARCHAR(100) NOT NULL, Contact CHAR(13) NOT NULL,    Address VARCHAR(100),
    PRIMARY KEY (N_ID));
CREATE TABLE blood_bags (Bag_ID INT NOT NULL AUTO_INCREMENT,    Donation_Date DATE,    Delivery_Date DATE,    S_ID INT,    D_CNIC CHAR(15),    R_CNIC CHAR(15),    N_ID INT,    PRIMARY KEY (Bag_ID),    FOREIGN KEY (S_ID) REFERENCES staff(S_ID),
FOREIGN KEY (D_CNIC) REFERENCES donor(D_CNIC),    FOREIGN KEY (R_CNIC) REFERENCES recipient(R_CNIC),  FOREIGN KEY (N_ID) REFERENCES networks(N_ID));
DELIMITER //

CREATE PROCEDURE GetEligibleDonors()
BEGIN
    SELECT
        d.D_CNIC AS Donor_identity,
        d.Name AS Donor_Name,
        d.Contact,
        d.Blood_Group,
        'Eligible' AS Eligibility_Status
    FROM
        DONOR d
    WHERE
        NOT EXISTS (
            SELECT 1
            FROM BLOOD_BAGS bb
            WHERE bb.D_CNIC = d.D_CNIC
        )
        OR (
            SELECT MAX(bb.Donation_Date)
            FROM BLOOD_BAGS bb
            WHERE bb.D_CNIC = d.D_CNIC
        ) <= DATE_SUB(CURRENT_DATE, INTERVAL 90 DAY);
END //

DELIMITER ;
DELIMITER //

CREATE PROCEDURE GetBloodBagCountsByMonth()
BEGIN
    SELECT
        DATE_FORMAT(bb.Donation_Date, '%Y-%m') AS Month,
        COUNT(bb.Bag_ID) AS Blood_Bag_Count
    FROM
        BLOOD_BAGS bb
    GROUP BY
        DATE_FORMAT(bb.Donation_Date, '%Y-%m');
END //

DELIMITER ;
DELIMITER //

CREATE PROCEDURE GetBloodBagDetails()
BEGIN
    SELECT
        BB.Bag_ID,
        BB.Delivery_Date,
        ADDDATE(BB.Delivery_Date, 30) AS Expiry_date,
        D.Name AS Donor_Name,
        D.Blood_Group,
        COUNT(BB.Bag_ID) AS NumberOfBags
    FROM
        blood_bags BB
    JOIN
        DONOR D ON BB.D_CNIC = D.D_CNIC
    GROUP BY
        BB.Bag_ID, BB.Delivery_Date, D.Name, D.Blood_Group
    ORDER BY
        Expiry_date;
END //

DELIMITER ;
